#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

/*void enqueue()
{
    
}
void dequeue()
{}
void print()
{}*/

int main() 
{
   int queue[10^5]={},*t,type,x,*a,q,tmp;

    scanf("%d",&q);
        
    t=queue-1;
    a=queue;
    
    printf("%u\n%u\n%u\n",a,t,queue);
    
    while(q-->0)
    {
        scanf("%d",&type);
        if(type==1)
        {
        	t++;
            scanf("%d",&x);
            
            *t=x;
        }
        else if(type==2)
        {
            while(t!=a)
            {
              tmp=*(++a);
			  *(--a)=tmp;
              a++;
            }
           t--;
           a=queue;
        }
        else if(type==3)
            printf("%d\n",*a);
         printf("                   %d",*t,*a);
            
    }
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */    
    return 0;
}

