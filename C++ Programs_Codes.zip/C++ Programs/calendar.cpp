#include<stdio.h>
#include<string.h>
#include<conio.h>
int getkey()
{
	int ch;
	
	ch=getch();
	
	if(ch==0)
	{
		ch=getch();
		
		return 0;
	}
	return ch;
}
int leap(int n)
{
	if(((n%4==0)&&(n%100!=0))||(n%400==0))
	 return 1;
	 else 
	 return 0;
}
void title(int m,int y)
{
	switch(m)
	{
		case 1:
			{
				printf("                    January ");
				break;
			}
			case 2:
			{
				printf("                    February ");
				break;
			}
			case 3:
			{
				printf("                    March ");
				break;
			}
			case 4:
			{
				printf("                    April ");
				break;
			}
			case 5:
			{
				printf("                    May ");
				break;
			}
			case 6:
			{
				printf("                    June ");
				break;
			}
			case 7:
			{
				printf("                    July ");
				break;
			}
			case 8:
			{
				printf("                    August ");
				break;
			}
			case 9:
			{
				printf("                    September ");
				break;
			}
			case 10:
			{
				printf("                    October ");
				break;
			}
			case 11:
			{
				printf("                    November ");
				break;
			}
			case 12:
			{
				printf("                    December ");
				break;
			}
	}
	printf("%d",y);
}
void fill(int n,int m)
{
	int i,f=n;
	
	for(i=0;i<(n*6-1);i++)
	  printf(" ");
	  
	  printf("1     ");
	  
	  f++;
	  f%=7;
	  
	  for(i=2;i<=m;i++)
	  {
	  	if(f==1)
	  	printf("\n     ");
	  	if(i<10)
	  	printf("%d     ",i);
	  	else if(i>9)
	  	printf("%d    ",i);
	  	
	  	f++;
	  	f%=7;
	  }
}
int main()
{
	char ca[]="    Mon   Tue   Wed   Thu   Fri   Sat   Sun";
	char lmnth[]={31,29,31,30,31,30,31,31,30,31,30,31};
	char nlmnth[]={31,28,31,30,31,30,31,31,30,31,30,31};
	int m,y,s=0,f=1,i,v;
	
	printf("enter month and year\n");
	
	scanf("%d%d",&m,&y);
	
	//fflush(stdin);
	
	while(f!=0)
	{
		printf("\n");
	//	s=0;
	title(m,y);
	
	s=0;
	
	printf("\n%s\n",ca);
	
	for(i=1;i<y;i++)
	   {
	   	 if(leap(i)==1)
	   	 s+=366;
	   	 else
	     s+=365;
	   }
	   
	   if(leap(y)==1)
	    for(i=1;i<m;i++)
	  	  s+=lmnth[i-1];      
       else
          for(i=1;i<m;i++)
	  	     s+=nlmnth[i-1];
	  	     
	  f=(s%7)+1;
	  
	  if(leap(y)==1)
	  fill(f,lmnth[m-1]);
	  else
	  fill(f,nlmnth[m-1]);
	  
	  printf("\nnow what?\n");
	  
	  v=getkey();
	  
	  if(v==72)//up
	  {
	  	y++;
	  	f=1;
	  	//printf("\n");
	  	
	  	continue;
	  }
	  else if(v==80)//down
	  {
	  	y--;
        f=1;
	  	printf("\n");
	  	
	  	continue;
	  }
	  else if(v==75)//left
	  {
	  	m++;
	  	f=1;
	  	//printf("\n");
	  	
	  	continue;
	  }
	  else if(v==77)//right
	  {
	  	m--;
	  	f=1;
	  //	printf("\n");
	  	
	  	continue;
	  }
	  else if(v==27)
	      break;
     }
	  
	  return 0;
}
