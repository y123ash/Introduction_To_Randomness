#include<stdio.h>
int rec(int n)
{
	if(n==0)
	return 1;
	else 
	return (n*rec(n-1));
}
int main()
{
	int n,f;
	
	scanf("%d",&n);
	
	f=rec(n);
	
	printf("f=%d\n",f);
	
	return 0;
}
